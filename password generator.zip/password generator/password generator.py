import tkinter as tk
import random
import string
import pyperclip

def generate_password():
    # Get the password length specified by the user
    password_length = int(length_entry.get())
    
    # Define character sets based on user preferences
    lowercase = string.ascii_lowercase if lowercase_var.get() else ''
    uppercase = string.ascii_uppercase if uppercase_var.get() else ''
    digits = string.digits if digits_var.get() else ''
    symbols = string.punctuation if symbols_var.get() else ''
    
    # Combine character sets
    all_chars = lowercase + uppercase + digits + symbols
    
    if all_chars:
        # Generate the password by randomly selecting characters from the combined set
        generated_password = ''.join(random.choice(all_chars) for _ in range(password_length))
        # Clear the password entry and insert the generated password
        password_entry.delete(0, tk.END)
        password_entry.insert(tk.END, generated_password)
    else:
        # Display a message if no character type is selected
        password_entry.delete(0, tk.END)
        password_entry.insert(tk.END, "Please select at least one character type.")

def copy_to_clipboard():
    # Get the generated password
    password = password_entry.get()
    if password:
        # Copy the password to the clipboard
        pyperclip.copy(password)
        # Display a status message
        status_label.config(text="Password copied to clipboard", fg="green")
    else:
        # Display an error message if no password is generated
        status_label.config(text="No password generated", fg="red")

# Create the main window
root = tk.Tk()
root.title("Password Generator")

# Password Length Label and Entry
length_label = tk.Label(root, text="Password Length:")
length_label.grid(row=0, column=0, padx=10, pady=5)
length_entry = tk.Entry(root)
length_entry.grid(row=0, column=1, padx=10, pady=5)
length_entry.insert(tk.END, "12")

# Character Type Checkboxes
lowercase_var = tk.BooleanVar()
lowercase_check = tk.Checkbutton(root, text="Lowercase", variable=lowercase_var)
lowercase_check.grid(row=1, column=0, padx=10, pady=5)

uppercase_var = tk.BooleanVar()
uppercase_check = tk.Checkbutton(root, text="Uppercase", variable=uppercase_var)
uppercase_check.grid(row=1, column=1, padx=10, pady=5)

digits_var = tk.BooleanVar()
digits_check = tk.Checkbutton(root, text="Digits", variable=digits_var)
digits_check.grid(row=2, column=0, padx=10, pady=5)

symbols_var = tk.BooleanVar()
symbols_check = tk.Checkbutton(root, text="Symbols", variable=symbols_var)
symbols_check.grid(row=2, column=1, padx=10, pady=5)

# Generate Password Button
generate_button = tk.Button(root, text="Generate Password", command=generate_password)
generate_button.grid(row=3, column=0, columnspan=2, padx=10, pady=5, sticky="WE")

# Generated Password Entry
password_entry = tk.Entry(root, width=30)
password_entry.grid(row=4, column=0, columnspan=2, padx=10, pady=5)

# Copy to Clipboard Button
copy_button = tk.Button(root, text="Copy to Clipboard", command=copy_to_clipboard)
copy_button.grid(row=5, column=0, columnspan=2, padx=10, pady=5, sticky="WE")

# Status Label
status_label = tk.Label(root, text="", fg="green")
status_label.grid(row=6, column=0, columnspan=2, padx=10, pady=5)

# Run the Tkinter event loop
root.mainloop()